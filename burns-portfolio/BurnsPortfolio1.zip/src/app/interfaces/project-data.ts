export interface ProjectData {
    cardImg: string;
    cardTitle: string;
    cardDesc: string;
    projectURL: string;
    linkText: string;
    iconUrls: string[];
}
